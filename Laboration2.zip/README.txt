Inspiration: loplabbet.se

Bilder: svårt att hitta flera passande bilder på löparskor som är "free use" men lyckades hitta 2 olika på Pixabay.com och sedan använda jag AI för att generera till bilder som är liknande

https://pixabay.com/photos/running-shoe-shoe-brooks-371624/
