# lia-portfolio
Samling av skolprojekt och övningar inom programmering och webbutveckling, skapade som del av min utbildning och inför LIA-praktik.
