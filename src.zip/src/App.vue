<script>

import Footer from "./components/Footer.vue";
import Header from "./components/Header.vue";
import Composition from "./components/SearchBar.vue";

  export default {
    components: {
      Composition,
      Footer,
      Header
    },

    data () {

      return {
        searchText:""
      }
    }
  };
</script>

<template>
  <Header v-model="searchText"/>
  <RouterView :searchText="searchText"/>
  <Footer/>

</template>
