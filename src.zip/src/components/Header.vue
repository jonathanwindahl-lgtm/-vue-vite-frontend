<script setup>
import SearchBar from '../components/SearchBar.vue';

const props = defineProps ({
  modelValue: String
})

const emit = defineEmits(['update:modelValue'])
</script>

<template>


<div class="top">
        <p>1-4 arbetsdagars leveranstid</p>
        <p>Fri frakt & retur till butik</p>
        <p>Öppet köp i 365 dagar</p>
    </div>
    <header class="head">


    <RouterLink to="/"><h1>Springskor</h1></RouterLink>

    <SearchBar :modelvalue="modelValue" @update:modelValue="emit('update:modelValue', $event)"/>

    <div class="divider"></div>

</header>
</template>

<style scoped>

.top {
  display: flex;
  background-color: #0077CC;
  color: white;
  justify-content: space-between;
  align-items: center;
  padding: 0px 10px;
  margin-bottom: 10px;
  font-size: 0.8rem;
}

.head {
  display: flex;
  align-items: center;

}
.search-wrapper {
  flex: 1;
  display: flex;
  justify-content: center;
}

a {
  color: #0077CC;
  text-decoration: none;
  font-weight: bold;
}

.divider {
  background-color: #0077CC;
  height: 5px;
  margin: 5px 0 10px;
}



</style>
