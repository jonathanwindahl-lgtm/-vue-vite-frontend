import { createRouter, createWebHistory } from "vue-router";
import ShoeGallery from "./views/ShoeGallery.vue"
import ProductDetail from "./views/ProductDetail.vue"

export default createRouter ({
  history:createWebHistory(),
  routes: [
    {
      path: "/",
      name: "home",
      component:ShoeGallery
    },
    {
      path: "/product/:id",
      name: "product",
      component: ProductDetail,
      props: true
    }
  ]
})
