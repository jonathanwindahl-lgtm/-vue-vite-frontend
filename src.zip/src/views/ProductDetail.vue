<script>

  export default {
    props: ["id"],

    data() {
      return {
        product: null
      };
    },

    mounted() {
      fetch(`https://6915a1dc84e8bd126afabb7f.mockapi.io/Products/${this.id}`)
      .then(response => response.json())
      .then(data =>

        this.product = data)
  }
}
</script>

<template>

    <div v-if="!product">Laddar Produkt...</div>

    <div v-else class="product-detail">
     <img :src="`/${product.imageUrl}`"  :alt="product.description" />
    <h3> {{ product.description}}</h3>
     <p>{{ product.price }} kr</p>


    <RouterLink to="/"> Tillbaka</RouterLink>

    </div>

</template>

<style>

* {
  font-weight: bold;
}
.product-detail {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  background-color: #fff;
  border-radius: 10px;
  padding: 1rem;
  transition: transform 0.3s ease, box-shadow 0.3 ease;
}

.product-detail:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.25);
}

.product-detail img {
  width: 50%;
  height: auto;
  object-fit: cover;
  border-radius: 6px;
  margin-bottom: 10px;
  transition: transform 0.3s ease;
}
a {

  text-decoration: none;
  font-weight: bold;
}

</style>
